# gitPractiseRepo
This was a Repo made to practise git basics
